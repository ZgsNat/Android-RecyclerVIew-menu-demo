package com.example.bonus10;

import android.annotation.SuppressLint;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private RecyclerView recyclerView;
    private ProductAdapter productAdapter;

    private void bindingView(){
        recyclerView = findViewById(R.id.reView);
        drawerLayout = findViewById(R.id.my_drawer_layout);
    }
    private void bindingAction(){
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);
        actionBarDrawerToggle.getDrawerArrowDrawable().setColor(getResources().getColor(android.R.color.white));
        // pass the Open and Close toggle for the drawer layout listener
        // to toggle the button
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.red)));
        getSupportActionBar().setTitle(Html.fromHtml("<font color='#FFFFFF'>Shop</font>"));
        getSupportActionBar().setElevation(0);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.my_drawer_layout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        bindingView();
        bindingAction();

        // to make the Navigation drawer icon always appear on the action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
// Set up RecyclerView
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));
        productAdapter = new ProductAdapter(getProducts(), this);
        recyclerView.setAdapter(productAdapter);

    }
    private List<Product> getProducts() {
        List<Product> products = new ArrayList<>();
        products.add(new Product("pharmacy", R.drawable.ic_pharmacy));
        products.add(new Product("register", R.drawable.ic_registry));
        products.add(new Product("cartwheel", R.drawable.ic_cartwheel));
        products.add(new Product("clothing", R.drawable.ic_clothing));
        products.add(new Product("shoes", R.drawable.ic_shoes));
        products.add(new Product("accessories", R.drawable.ic_accessories));
        products.add(new Product("baby", R.drawable.ic_baby));
        products.add(new Product("home", R.drawable.ic_home));
        products.add(new Product("patio & garden", R.drawable.ic_patio));
        return products;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @SuppressLint("ResourceType")
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.options_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
}